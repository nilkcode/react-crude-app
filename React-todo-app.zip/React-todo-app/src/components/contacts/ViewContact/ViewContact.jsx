import React from 'react';
import { Link } from 'react-router-dom'


const ViewContact = () => {
  return (
    <> 
                
       <div className='mt-5'>
         <div className="card card-custome w-50 m-auto bg-secondary-gray" >

                    <img className='card-img-top' style={{width:"152px",height:"152px",borderRadius:"50%",padding:"4px"}} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcShJk_vj0wIS2WqLClrCGqp5aWzLDrv62TDzpFDg90&s" alt="" />
                    <div className='card-body'>
                        <div className='d-flex justify-content-between mb-2'>
                            <div className='d-flex flex-start'>
                                <div><label className='mr-2'>Name:</label></div>
                                <div><label className='label-value'>Akash Ganate </label></div>
                            </div>
                            <div>
                            <Link type="button" class="btn btn-warning" to="/contacts/list"><i className='fa fa-arrow-left mr-2'></i>Back</Link>
                            </div>
                            
                        </div>
                        <div className='d-flex justify-content-between mb-2'>
                            <div className='d-flex flex-start'>
                                <div><label className='mr-2'>Mobile:</label></div>
                                <div><label className='label-value'>282828282 </label></div>
                            </div>
                            <div>
                            </div>
                            
                        </div>
                        <div className='d-flex justify-content-between mb-2'>
                            <div className='d-flex flex-start'>
                                <div><label className='mr-2'>Email </label></div>
                                <div><label className='label-value'>akashganate@gmail.com </label></div>
                            </div>
                            <div>
                            </div>
                            
                        </div>
                        <div className='d-flex justify-content-between mb-2'>
                            <div className='d-flex flex-start'>
                                <div><label className='mr-2'>Company:</label></div>
                                <div><label className='label-value'>Akash Ganate </label></div>
                            </div>
                            
                            
                        </div>
                        <div className='d-flex justify-content-between mb-2'>
                            <div className='d-flex flex-start'>
                                <div><label className='mr-2'>Title:</label></div>
                                <div><label className='label-value'>282828282 </label></div>
                            </div>
                            <div>
                            </div>
                            
                        </div>
                        <div className='d-flex justify-content-between mb-2'>
                            <div className='d-flex flex-start'>
                                <div><label className='mr-2'>Group </label></div>
                                <div><label className='label-value'>akashganate@gmail.com </label></div>
                            </div>
                            <div>
                            </div>
                            
                        </div>
                    </div>
                </div>
       </div>
    </>
  )
}

export default ViewContact